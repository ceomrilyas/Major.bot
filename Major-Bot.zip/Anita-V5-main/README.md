# Major-Bot
   <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center"> 
<u>⚡ A simple WhatsApp Bot Coded By Major CyberWarrior ⚡</u>
</p>
<p align="center">
<img src="https://files.catbox.moe/0ly0h6.jpg"/>       
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•MAJOR+BOT•;MULTI-DEVICE+WHATSAPP+BOT;DEVELOPED+BY+MR+ILYAS;MAJOR+CYBERWARRIOR." alt="Typing SVG" /></a>
</p> 
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-MR_ILYAS-red.svg?style=for-the-badge&logo=github"></a>
</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
#

## Major-Bot Deployment Methods
---
1. **Get SESSION ID via Pairing Code**
2. **Deploy on [RENDER](https://dashboard.render.com/signup)**
3. **Deploy on [KOYEB](https://app.koyeb.com)**
4. **Deploy on [HEROKU](https://dashboard.heroku.com)**

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## `Connect With Me`
<p align="center">
<a href="https://wa.me/923427941197"><img src="https://img.shields.io/badge/Contact Mr Ilyas-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

- *Major-Bot is not made by WhatsApp Inc. Misusing the bot might ban your WhatsApp account!*
- *Use Major-Bot at your own risk.*
